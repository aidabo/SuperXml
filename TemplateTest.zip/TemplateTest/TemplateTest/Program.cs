﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Xml;
using System.IO;
using SuperXML;

namespace TemplateTest
{
    class Program
    {
        String getFilePath(String filename)
        {
            String dir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            return Path.Combine(dir, filename);
        }

        void test1()
        {
            Compiler compiler = new Compiler();
            var result = compiler.AddKey("name", "Excel")
                .AddKey("width", 100)
                .AddKey("height", 500)
                .AddKey("bounds", new[] { 10, 0, 10, 0 })
                .AddKey("elements", new[]
                {
                    new { name = "John", age= 10 },
                    new { name = "Maria", age= 57 },
                    new { name = "Mark", age= 23 },
                    new { name = "Edit", age= 82 },
                    new { name = "Susan", age= 37 }
                })
                .CompileXml(new FileStream(getFilePath("test1.xml"), FileMode.Open));
            Console.WriteLine(result);
        }

        void test()
        {
            Compiler compiler = new Compiler();
            var result = compiler.AddKey("name", "Excel")
                .AddKey("width", 100)
                .AddKey("height", 500)
                .AddKey("bounds", new[] { 10, 0, 10, 0 })
                .AddKey("elements", new[]
                {
                    new { name = "John", age= 10 },
                    new { name = "Maria", age= 57 },
                    new { name = "Mark", age= 23 },
                    new { name = "Edit", age= 82 },
                    new { name = "Susan", age= 37 }
                })
                .CompileString(File.ReadAllText(getFilePath("test.txt")));
            Console.WriteLine(result);
        }

        void test2()
        {
            Compiler compiler = new Compiler();
            var result = compiler
                .AddKey("numbers", new[] { 10, 0, 10, 0 })
                .CompileXml(new FileStream(getFilePath("test2.xml"), FileMode.Open));
            Console.WriteLine(result);
        }


        static void Main(string[] args)
        {
            Program p = new Program();
            p.test2();
        }
    }
}
